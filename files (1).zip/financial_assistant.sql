BEGIN TRANSACTION;
CREATE TABLE alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,              -- 'overspend' | 'large_debit' | 'unused_sub'
    message TEXT NOT NULL,
    data_json TEXT,                  -- supporting numbers as JSON string
    created_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
INSERT INTO "alerts" VALUES(1,1,'large_debit','Large one-off debit at Croma Electronics today.','{"merchant": "Croma Electronics", "amount": -18500.0, "date": "2026-09-11"}','2026-09-11T09:15:00');
INSERT INTO "alerts" VALUES(2,1,'overspend','Discretionary spend is on track to exceed last month''s by ~18%.','{"this_month_discretionary": 27189.0, "last_month_discretionary": 23050.0, "pct_over": 18.0}','2026-09-11T09:16:00');
INSERT INTO "alerts" VALUES(3,1,'unused_sub','Gold''s Gym charged 4 months running with no matching check-in data — confirm it''s still used.','{"merchant": "Gold''s Gym", "monthly_amount": 1500.0, "months_charged": 4}','2026-09-09T08:00:00');
INSERT INTO "alerts" VALUES(4,2,'large_debit','Large one-off debit at Vijay Sales today.','{"merchant": "Vijay Sales", "amount": -12000.0, "date": "2026-09-11"}','2026-09-11T10:05:00');
INSERT INTO "alerts" VALUES(5,2,'overspend','Discretionary spend this month is running ~12% above the 3-month average.','{"this_month_discretionary": 17566.0, "avg_3mo_discretionary": 15680.0, "pct_over": 12.0}','2026-09-10T08:30:00');
CREATE TABLE goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,              -- e.g. "Emergency Fund"
    target_amount REAL NOT NULL,
    current_amount REAL DEFAULT 0,
    target_date TEXT NOT NULL,       -- ISO date
    FOREIGN KEY (user_id) REFERENCES users(id)
);
INSERT INTO "goals" VALUES(1,1,'Emergency Fund',300000.0,65000.0,'2027-05-01');
INSERT INTO "goals" VALUES(2,2,'New Laptop',90000.0,22000.0,'2027-02-01');
CREATE TABLE liabilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,              -- e.g. "Car Loan", "Credit Card"
    balance REAL NOT NULL,
    interest_rate REAL NOT NULL,     -- annual %, e.g. 14.5
    min_payment REAL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
INSERT INTO "liabilities" VALUES(1,1,'HDFC Car Loan',210000.0,11.5,8500.0);
INSERT INTO "liabilities" VALUES(2,1,'ICICI Credit Card',45000.0,42.0,4500.0);
INSERT INTO "liabilities" VALUES(3,2,'Bajaj Bike Loan',38000.0,13.0,3200.0);
INSERT INTO "liabilities" VALUES(4,2,'Personal Loan',120000.0,18.5,5400.0);
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,              -- ISO format YYYY-MM-DD
    merchant TEXT NOT NULL,
    amount REAL NOT NULL,            -- negative = debit, positive = credit
    category TEXT,                   -- e.g. Food, Rent, EMI, Subscription, Salary
    type TEXT,                       -- 'essential' | 'discretionary' | 'income'
    is_recurring INTEGER DEFAULT 0,  -- 0 or 1
    FOREIGN KEY (user_id) REFERENCES users(id)
);
INSERT INTO "transactions" VALUES(1,1,'2026-09-01','Acme Corp Salary',85000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(2,1,'2026-08-01','Acme Corp Salary',85000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(3,1,'2026-07-01','Acme Corp Salary',82000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(4,1,'2026-09-03','Sunrise Apartments',-22000.0,'Rent','essential',1);
INSERT INTO "transactions" VALUES(5,1,'2026-08-03','Sunrise Apartments',-22000.0,'Rent','essential',1);
INSERT INTO "transactions" VALUES(6,1,'2026-09-05','HDFC Car Loan EMI',-8500.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(7,1,'2026-08-05','HDFC Car Loan EMI',-8500.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(8,1,'2026-09-07','BESCOM Electricity',-1800.0,'Utilities','essential',1);
INSERT INTO "transactions" VALUES(9,1,'2026-09-07','Airtel Broadband',-999.0,'Utilities','essential',1);
INSERT INTO "transactions" VALUES(10,1,'2026-09-10','BigBasket Groceries',-4200.0,'Food','essential',0);
INSERT INTO "transactions" VALUES(11,1,'2026-09-18','BigBasket Groceries',-3600.0,'Food','essential',0);
INSERT INTO "transactions" VALUES(12,1,'2026-09-02','Netflix',-649.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(13,1,'2026-08-02','Netflix',-649.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(14,1,'2026-07-02','Netflix',-649.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(15,1,'2026-09-04','Spotify',-119.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(16,1,'2026-08-04','Spotify',-119.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(17,1,'2026-09-06','Amazon Prime',-299.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(18,1,'2026-09-09','Gold''s Gym',-1500.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(19,1,'2026-08-09','Gold''s Gym',-1500.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(20,1,'2026-07-09','Gold''s Gym',-1500.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(21,1,'2026-06-09','Gold''s Gym',-1500.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(22,1,'2026-09-12','Zomato',-650.0,'Food','discretionary',0);
INSERT INTO "transactions" VALUES(23,1,'2026-09-14','Swiggy',-480.0,'Food','discretionary',0);
INSERT INTO "transactions" VALUES(24,1,'2026-09-15','PVR Cinemas',-900.0,'Entertainment','discretionary',0);
INSERT INTO "transactions" VALUES(25,1,'2026-09-20','Myntra',-3200.0,'Shopping','discretionary',0);
INSERT INTO "transactions" VALUES(26,1,'2026-09-08','Uber',-340.0,'Transport','discretionary',0);
INSERT INTO "transactions" VALUES(27,1,'2026-09-10','Starbucks',-520.0,'Food','discretionary',0);
INSERT INTO "transactions" VALUES(28,1,'2026-09-11','Croma Electronics',-18500.0,'Shopping','discretionary',0);
INSERT INTO "transactions" VALUES(29,2,'2026-09-01','Nimbus Tech Salary',62000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(30,2,'2026-08-01','Nimbus Tech Salary',62000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(31,2,'2026-07-01','Nimbus Tech Salary',60000.0,'Salary','income',1);
INSERT INTO "transactions" VALUES(32,2,'2026-09-02','Green Meadows PG',-12000.0,'Rent','essential',1);
INSERT INTO "transactions" VALUES(33,2,'2026-08-02','Green Meadows PG',-12000.0,'Rent','essential',1);
INSERT INTO "transactions" VALUES(34,2,'2026-09-06','Bajaj Finserv Bike EMI',-3200.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(35,2,'2026-08-06','Bajaj Finserv Bike EMI',-3200.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(36,2,'2026-09-08','Personal Loan EMI',-5400.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(37,2,'2026-08-08','Personal Loan EMI',-5400.0,'EMI','essential',1);
INSERT INTO "transactions" VALUES(38,2,'2026-09-11','DMart Groceries',-3100.0,'Food','essential',0);
INSERT INTO "transactions" VALUES(39,2,'2026-09-19','DMart Groceries',-2800.0,'Food','essential',0);
INSERT INTO "transactions" VALUES(40,2,'2026-09-03','Netflix',-649.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(41,2,'2026-08-03','Netflix',-649.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(42,2,'2026-09-05','Hotstar',-299.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(43,2,'2026-08-05','Hotstar',-299.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(44,2,'2026-07-05','Hotstar',-299.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(45,2,'2026-09-07','Cult.fit',-999.0,'Subscription','discretionary',1);
INSERT INTO "transactions" VALUES(46,2,'2026-09-13','Domino''s Pizza',-540.0,'Food','discretionary',0);
INSERT INTO "transactions" VALUES(47,2,'2026-09-16','Ola Cabs',-280.0,'Transport','discretionary',0);
INSERT INTO "transactions" VALUES(48,2,'2026-09-22','Decathlon',-2100.0,'Shopping','discretionary',0);
INSERT INTO "transactions" VALUES(49,2,'2026-09-07','BookMyShow',-700.0,'Entertainment','discretionary',0);
INSERT INTO "transactions" VALUES(50,2,'2026-09-11','Vijay Sales',-12000.0,'Shopping','discretionary',0);
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);
INSERT INTO "users" VALUES(1,'Priya Sharma');
INSERT INTO "users" VALUES(2,'Rahul Mehta');
INSERT INTO "users" VALUES(3,'Demo Guest');
CREATE INDEX idx_transactions_user_date ON transactions(user_id, date);
CREATE INDEX idx_goals_user ON goals(user_id);
CREATE INDEX idx_liabilities_user ON liabilities(user_id);
CREATE INDEX idx_alerts_user ON alerts(user_id);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('users',3);
INSERT INTO "sqlite_sequence" VALUES('transactions',50);
INSERT INTO "sqlite_sequence" VALUES('goals',2);
INSERT INTO "sqlite_sequence" VALUES('liabilities',4);
INSERT INTO "sqlite_sequence" VALUES('alerts',5);
COMMIT;
