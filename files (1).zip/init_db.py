"""
init_db.py — SQLite schema + demo seed data for the
Personal Financial Health Assistant (FinTech PS #3)

Usage:
    python init_db.py                # create tables if missing, seed if empty
    python init_db.py --reset        # drop everything and rebuild + reseed
    python init_db.py --no-seed      # only create tables, skip demo data

Schema is copied verbatim from DATABASE.md. Seed data follows the
"Target Demo User" section of PRD.md:
    salaried individual with monthly salary credit, rent, 1-2 EMIs,
    3-4 recurring subscriptions, discretionary spends, 1 savings goal,
    1-2 active loans/cards.

Per DATABASE.md notes: since auth is out of scope for the hackathon,
`users` is seeded with a few demo rows instead of wiring real auth.
"""

import argparse
import json
import sqlite3
from datetime import date, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent / "financial_assistant.db"

# ---------------------------------------------------------------------------
# Schema — verbatim from DATABASE.md
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,              -- ISO format YYYY-MM-DD
    merchant TEXT NOT NULL,
    amount REAL NOT NULL,            -- negative = debit, positive = credit
    category TEXT,                   -- e.g. Food, Rent, EMI, Subscription, Salary
    type TEXT,                       -- 'essential' | 'discretionary' | 'income'
    is_recurring INTEGER DEFAULT 0,  -- 0 or 1
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,              -- e.g. "Emergency Fund"
    target_amount REAL NOT NULL,
    current_amount REAL DEFAULT 0,
    target_date TEXT NOT NULL,       -- ISO date
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS liabilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,              -- e.g. "Car Loan", "Credit Card"
    balance REAL NOT NULL,
    interest_rate REAL NOT NULL,     -- annual %, e.g. 14.5
    min_payment REAL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,              -- 'overspend' | 'large_debit' | 'unused_sub'
    message TEXT NOT NULL,
    data_json TEXT,                  -- supporting numbers as JSON string
    created_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
"""

# Helpful indexes (not in the original doc, but harmless/standard — speeds up
# the dashboard queries this schema is clearly meant for). Left out of SCHEMA
# above so the literal DATABASE.md contract stays untouched; added separately.
INDEXES = """
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_goals_user ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_liabilities_user ON liabilities(user_id);
CREATE INDEX IF NOT EXISTS idx_alerts_user ON alerts(user_id);
"""


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.executescript(INDEXES)
    conn.commit()


def reset_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        DROP TABLE IF EXISTS alerts;
        DROP TABLE IF EXISTS liabilities;
        DROP TABLE IF EXISTS goals;
        DROP TABLE IF EXISTS transactions;
        DROP TABLE IF EXISTS users;
        """
    )
    conn.commit()
    create_schema(conn)


# ---------------------------------------------------------------------------
# Demo seed data
# ---------------------------------------------------------------------------

def _d(days_ago: int) -> str:
    """ISO date `days_ago` days before today."""
    return (date.today() - timedelta(days=days_ago)).isoformat()


def _month_day(day: int, months_back: int = 0) -> str:
    """ISO date for `day` of the current month, `months_back` months back."""
    today = date.today()
    month = today.month - months_back
    year = today.year
    while month <= 0:
        month += 12
        year -= 1
    while month > 12:
        month -= 12
        year += 1
    return date(year, month, day).isoformat()


def seed_user_1(conn: sqlite3.Connection, user_id: int) -> None:
    """Priya Sharma — salaried, 1 EMI, 1 credit card, saving for an emergency fund."""

    transactions = [
        # -- income --
        (user_id, _month_day(1, 0), "Acme Corp Salary", 85000.0, "Salary", "income", 1),
        (user_id, _month_day(1, 1), "Acme Corp Salary", 85000.0, "Salary", "income", 1),
        (user_id, _month_day(1, 2), "Acme Corp Salary", 82000.0, "Salary", "income", 1),
        # -- essential / recurring --
        (user_id, _month_day(3, 0), "Sunrise Apartments", -22000.0, "Rent", "essential", 1),
        (user_id, _month_day(3, 1), "Sunrise Apartments", -22000.0, "Rent", "essential", 1),
        (user_id, _month_day(5, 0), "HDFC Car Loan EMI", -8500.0, "EMI", "essential", 1),
        (user_id, _month_day(5, 1), "HDFC Car Loan EMI", -8500.0, "EMI", "essential", 1),
        (user_id, _month_day(7, 0), "BESCOM Electricity", -1800.0, "Utilities", "essential", 1),
        (user_id, _month_day(7, 0), "Airtel Broadband", -999.0, "Utilities", "essential", 1),
        (user_id, _month_day(10, 0), "BigBasket Groceries", -4200.0, "Food", "essential", 0),
        (user_id, _month_day(18, 0), "BigBasket Groceries", -3600.0, "Food", "essential", 0),
        # -- subscriptions (recurring, discretionary) --
        (user_id, _month_day(2, 0), "Netflix", -649.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(2, 1), "Netflix", -649.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(2, 2), "Netflix", -649.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(4, 0), "Spotify", -119.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(4, 1), "Spotify", -119.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(6, 0), "Amazon Prime", -299.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(9, 0), "Gold's Gym", -1500.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(9, 1), "Gold's Gym", -1500.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(9, 2), "Gold's Gym", -1500.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(9, 3), "Gold's Gym", -1500.0, "Subscription", "discretionary", 1),
        # -- discretionary / one-off --
        (user_id, _month_day(12, 0), "Zomato", -650.0, "Food", "discretionary", 0),
        (user_id, _month_day(14, 0), "Swiggy", -480.0, "Food", "discretionary", 0),
        (user_id, _month_day(15, 0), "PVR Cinemas", -900.0, "Entertainment", "discretionary", 0),
        (user_id, _month_day(20, 0), "Myntra", -3200.0, "Shopping", "discretionary", 0),
        (user_id, _d(3), "Uber", -340.0, "Transport", "discretionary", 0),
        (user_id, _d(1), "Starbucks", -520.0, "Food", "discretionary", 0),
        (user_id, _d(0), "Croma Electronics", -18500.0, "Shopping", "discretionary", 0),
    ]

    goals = [
        (user_id, "Emergency Fund", 300000.0, 65000.0, _month_day(1, -8)),  # 8 months out
    ]

    liabilities = [
        (user_id, "HDFC Car Loan", 210000.0, 11.5, 8500.0),
        (user_id, "ICICI Credit Card", 45000.0, 42.0, 4500.0),
    ]

    alerts = [
        (
            user_id,
            "large_debit",
            "Large one-off debit at Croma Electronics today.",
            json.dumps({"merchant": "Croma Electronics", "amount": -18500.0, "date": _d(0)}),
            _d(0) + "T09:15:00",
        ),
        (
            user_id,
            "overspend",
            "Discretionary spend is on track to exceed last month's by ~18%.",
            json.dumps({"this_month_discretionary": 27189.0, "last_month_discretionary": 23050.0, "pct_over": 18.0}),
            _d(0) + "T09:16:00",
        ),
        (
            user_id,
            "unused_sub",
            "Gold's Gym charged 4 months running with no matching check-in data — confirm it's still used.",
            json.dumps({"merchant": "Gold's Gym", "monthly_amount": 1500.0, "months_charged": 4}),
            _d(2) + "T08:00:00",
        ),
    ]

    conn.executemany(
        "INSERT INTO transactions (user_id, date, merchant, amount, category, type, is_recurring) VALUES (?,?,?,?,?,?,?)",
        transactions,
    )
    conn.executemany(
        "INSERT INTO goals (user_id, name, target_amount, current_amount, target_date) VALUES (?,?,?,?,?)",
        goals,
    )
    conn.executemany(
        "INSERT INTO liabilities (user_id, name, balance, interest_rate, min_payment) VALUES (?,?,?,?,?)",
        liabilities,
    )
    conn.executemany(
        "INSERT INTO alerts (user_id, type, message, data_json, created_at) VALUES (?,?,?,?,?)",
        alerts,
    )


def seed_user_2(conn: sqlite3.Connection, user_id: int) -> None:
    """Rahul Mehta — salaried, 2 EMIs (bike + personal loan), 3 subs, saving for a laptop."""

    transactions = [
        (user_id, _month_day(1, 0), "Nimbus Tech Salary", 62000.0, "Salary", "income", 1),
        (user_id, _month_day(1, 1), "Nimbus Tech Salary", 62000.0, "Salary", "income", 1),
        (user_id, _month_day(1, 2), "Nimbus Tech Salary", 60000.0, "Salary", "income", 1),
        (user_id, _month_day(2, 0), "Green Meadows PG", -12000.0, "Rent", "essential", 1),
        (user_id, _month_day(2, 1), "Green Meadows PG", -12000.0, "Rent", "essential", 1),
        (user_id, _month_day(6, 0), "Bajaj Finserv Bike EMI", -3200.0, "EMI", "essential", 1),
        (user_id, _month_day(6, 1), "Bajaj Finserv Bike EMI", -3200.0, "EMI", "essential", 1),
        (user_id, _month_day(8, 0), "Personal Loan EMI", -5400.0, "EMI", "essential", 1),
        (user_id, _month_day(8, 1), "Personal Loan EMI", -5400.0, "EMI", "essential", 1),
        (user_id, _month_day(11, 0), "DMart Groceries", -3100.0, "Food", "essential", 0),
        (user_id, _month_day(19, 0), "DMart Groceries", -2800.0, "Food", "essential", 0),
        (user_id, _month_day(3, 0), "Netflix", -649.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(3, 1), "Netflix", -649.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(5, 0), "Hotstar", -299.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(5, 1), "Hotstar", -299.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(5, 2), "Hotstar", -299.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(7, 0), "Cult.fit", -999.0, "Subscription", "discretionary", 1),
        (user_id, _month_day(13, 0), "Domino's Pizza", -540.0, "Food", "discretionary", 0),
        (user_id, _month_day(16, 0), "Ola Cabs", -280.0, "Transport", "discretionary", 0),
        (user_id, _month_day(22, 0), "Decathlon", -2100.0, "Shopping", "discretionary", 0),
        (user_id, _d(4), "BookMyShow", -700.0, "Entertainment", "discretionary", 0),
        (user_id, _d(0), "Vijay Sales", -12000.0, "Shopping", "discretionary", 0),
    ]

    goals = [
        (user_id, "New Laptop", 90000.0, 22000.0, _month_day(1, -5)),
    ]

    liabilities = [
        (user_id, "Bajaj Bike Loan", 38000.0, 13.0, 3200.0),
        (user_id, "Personal Loan", 120000.0, 18.5, 5400.0),
    ]

    alerts = [
        (
            user_id,
            "large_debit",
            "Large one-off debit at Vijay Sales today.",
            json.dumps({"merchant": "Vijay Sales", "amount": -12000.0, "date": _d(0)}),
            _d(0) + "T10:05:00",
        ),
        (
            user_id,
            "overspend",
            "Discretionary spend this month is running ~12% above the 3-month average.",
            json.dumps({"this_month_discretionary": 17566.0, "avg_3mo_discretionary": 15680.0, "pct_over": 12.0}),
            _d(1) + "T08:30:00",
        ),
    ]

    conn.executemany(
        "INSERT INTO transactions (user_id, date, merchant, amount, category, type, is_recurring) VALUES (?,?,?,?,?,?,?)",
        transactions,
    )
    conn.executemany(
        "INSERT INTO goals (user_id, name, target_amount, current_amount, target_date) VALUES (?,?,?,?,?)",
        goals,
    )
    conn.executemany(
        "INSERT INTO liabilities (user_id, name, balance, interest_rate, min_payment) VALUES (?,?,?,?,?)",
        liabilities,
    )
    conn.executemany(
        "INSERT INTO alerts (user_id, type, message, data_json, created_at) VALUES (?,?,?,?,?)",
        alerts,
    )


def seed_database(conn: sqlite3.Connection) -> None:
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] > 0:
        print("Users already present — skipping seed (use --reset to reseed).")
        return

    cur.execute("INSERT INTO users (name) VALUES (?)", ("Priya Sharma",))
    user1_id = cur.lastrowid
    cur.execute("INSERT INTO users (name) VALUES (?)", ("Rahul Mehta",))
    user2_id = cur.lastrowid
    # a third, near-empty user to demonstrate the "no data yet" state
    cur.execute("INSERT INTO users (name) VALUES (?)", ("Demo Guest",))

    seed_user_1(conn, user1_id)
    seed_user_2(conn, user2_id)

    conn.commit()
    print(f"Seeded 3 users (ids will vary), full demo data for user_id={user1_id} and user_id={user2_id}.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize the SQLite database.")
    parser.add_argument("--reset", action="store_true", help="Drop and recreate all tables before seeding.")
    parser.add_argument("--no-seed", action="store_true", help="Only create schema, skip demo data.")
    args = parser.parse_args()

    conn = get_conn()
    try:
        if args.reset:
            reset_schema(conn)
        else:
            create_schema(conn)

        if not args.no_seed:
            seed_database(conn)
    finally:
        conn.close()

    print(f"Database ready at: {DB_PATH}")


if __name__ == "__main__":
    main()
